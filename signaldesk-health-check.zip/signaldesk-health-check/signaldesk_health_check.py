"""
SignalDesk Weekly Health Check
==============================

A small, reusable tool a teammate can run on the weekly usage export to get an
honest read in seconds: what's working, what looks suspicious, and what to look
at next -- WITHOUT trusting a bad average.

The point of this tool is judgment, not a BI system. It does three things:

  1. Runs data-quality guardrails on the raw export and reports every issue it
     finds (duplicates, casing, text-in-numeric columns, missing values,
     impossible values, and demo/test-traffic spikes).
  2. Computes comparable, RATE-based metrics on the cleaned data -- never raw
     counts averaged across workflows of very different sizes.
  3. Prints a plain-language verdict per workflow, and is explicit about which
     numbers to trust least and what it deliberately does NOT conclude.

Usage:
    python signaldesk_health_check.py                       # uses bundled sample
    python signaldesk_health_check.py path/to/export.csv    # any weekly export
    python signaldesk_health_check.py export.csv --md out.md # also save report

Design choices worth knowing (see README):
  * `median_confidence` is model self-reported and is treated as the LEAST
    trustworthy signal -- it is reported but never used to judge quality.
  * The "new prompt version" (Aug 4) and "review policy change" (Aug 7) are
    surfaced as events. The tool refuses to declare the Aug 7 change good or
    bad, because it only has a partial day of data after it -- that honesty is
    the intended output.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field

import pandas as pd

# Metrics we treat as directional-only (model-reported or noisy estimates).
# They are shown but flagged, never used as the basis for a verdict.
LOW_TRUST_COLS = ["median_confidence", "avg_minutes_saved"]

# A row whose sessions exceed this multiple of the typical volume for its own
# (workflow, source) group is flagged as a likely demo/test spike, not real use.
SPIKE_MULTIPLE = 2.5


@dataclass
class Issue:
    kind: str
    detail: str


@dataclass
class HealthReport:
    issues: list[Issue] = field(default_factory=list)
    rows_in: int = 0
    rows_used: int = 0
    workflow_table: pd.DataFrame | None = None
    events: list[str] = field(default_factory=list)

    def add(self, kind: str, detail: str) -> None:
        self.issues.append(Issue(kind, detail))


# --------------------------------------------------------------------------- #
# Data quality guardrails
# --------------------------------------------------------------------------- #
def clean(df_raw: pd.DataFrame, report: HealthReport) -> pd.DataFrame:
    """Return a cleaned frame and log every fix/flag onto `report`."""
    df = df_raw.copy()
    report.rows_in = len(df)

    # --- 1. Exact duplicate export rows -------------------------------------
    dup_mask = df.duplicated(
        subset=[c for c in df.columns if c != "notes"], keep="first"
    )
    if dup_mask.any():
        for _, r in df[dup_mask].iterrows():
            report.add(
                "duplicate_row",
                f"{r['date']} {r['team']}/{r['workflow']} "
                f"({int(r['sessions'])} sessions) -- dropped 1 exact duplicate.",
            )
        df = df[~dup_mask].copy()

    # --- 2. Inconsistent team casing / whitespace ---------------------------
    raw_team = df["team"].astype(str).str.strip()
    norm_team = raw_team.str.title()
    changed = raw_team != norm_team
    for val in sorted(raw_team[changed].unique()):
        report.add(
            "team_casing",
            f"team '{val}' normalized to '{val.title()}' "
            f"(would otherwise split one team into two).",
        )
    df["team"] = norm_team

    # --- 3. Text in numeric columns (e.g. median_confidence = 'n/a') --------
    numeric_cols = [
        "sessions", "completed", "accepted_output", "flagged_for_review",
        "avg_minutes_saved", "median_confidence", "user_rating",
    ]
    for col in numeric_cols:
        coerced = pd.to_numeric(df[col], errors="coerce")
        newly_null = coerced.isna() & df[col].notna()
        for _, r in df[newly_null].iterrows():
            report.add(
                "non_numeric",
                f"{r['date']} {r['team']}/{r['workflow']}: {col}='{r[col]}' "
                f"is not a number -> treated as missing.",
            )
        df[col] = coerced

    # --- 4. Missing values ---------------------------------------------------
    for col in numeric_cols:
        n_missing = int(df[col].isna().sum())
        if n_missing:
            report.add(
                "missing_value",
                f"{col}: {n_missing} missing value(s) -- excluded from that "
                f"column's averages only, row otherwise kept.",
            )

    # --- 5. Impossible / inconsistent counts --------------------------------
    # Funnel must shrink: accepted <= completed <= sessions; flags <= sessions.
    checks = [
        ("completed", "sessions"),
        ("accepted_output", "completed"),
        ("flagged_for_review", "sessions"),
    ]
    for smaller, larger in checks:
        bad = df[smaller] > df[larger]
        for _, r in df[bad].iterrows():
            report.add(
                "impossible_value",
                f"{r['date']} {r['team']}/{r['workflow']}: {smaller} "
                f"({r[smaller]}) > {larger} ({r[larger]}) -- funnel violation.",
            )

    # --- 6. Demo / test-traffic spikes --------------------------------------
    # Compare each row's sessions to the median for its own (workflow, source).
    df["is_spike"] = False
    grp = df.groupby(["workflow", "source"])["sessions"]
    med = grp.transform("median")
    spike = df["sessions"] > SPIKE_MULTIPLE * med
    df.loc[spike, "is_spike"] = True
    for _, r in df[spike].iterrows():
        note = f" (note: '{r['notes']}')" if pd.notna(r.get("notes")) else ""
        report.add(
            "traffic_spike",
            f"{r['date']} {r['team']}/{r['workflow']}/{r['source']}: "
            f"{int(r['sessions'])} sessions vs ~{med[r.name]:.0f} typical "
            f"-> excluded from trend as likely demo/test traffic{note}.",
        )

    return df


# --------------------------------------------------------------------------- #
# Metrics (rate-based, comparable) + verdicts
# --------------------------------------------------------------------------- #
def summarize(df: pd.DataFrame, report: HealthReport) -> pd.DataFrame:
    """Aggregate to one row per workflow using comparable rates."""
    usable = df[~df["is_spike"]].copy()
    report.rows_used = len(usable)

    g = usable.groupby("workflow")
    out = pd.DataFrame({
        "days": g["date"].nunique(),
        "sessions": g["sessions"].sum(),
        "completion_rate": g["completed"].sum() / g["sessions"].sum(),
        "acceptance_rate": g["accepted_output"].sum() / g["completed"].sum(),
        "flag_rate": g["flagged_for_review"].sum() / g["sessions"].sum(),
        "avg_rating": g["user_rating"].mean(),
        "avg_min_saved": g["avg_minutes_saved"].mean(),
    })
    return out.sort_values("sessions", ascending=False)


def detect_events(df: pd.DataFrame) -> list[str]:
    """Surface documented change events from the notes column."""
    events = []
    notes = df["notes"].astype(str).str.lower()
    if notes.str.contains("new prompt").any():
        d = df.loc[notes.str.contains("new prompt"), "date"].min()
        events.append(f"New prompt version rolled out around {d}.")
    if notes.str.contains("policy").any():
        row = df.loc[notes.str.contains("policy")].iloc[0]
        events.append(
            f"Review policy changed on {row['date']} "
            f"({row['team']}/{row['workflow']}) -- partial-day data only."
        )
    return events


def verdict_lines(table: pd.DataFrame) -> list[str]:
    """Turn the numbers into a plain-language, honest read per workflow."""
    lines = []
    for wf, r in table.iterrows():
        acc = r["acceptance_rate"]
        small = r["sessions"] < 100  # low-volume caveat
        if small:
            tag = "LOW VOLUME - directional only"
        elif acc >= 0.75:
            tag = "WORKING - trust the signal"
        elif acc >= 0.60:
            tag = "OK - watch it"
        else:
            tag = "WEAK - needs a look"
        lines.append(
            f"  - {wf}: acceptance {acc:.0%}, completion "
            f"{r['completion_rate']:.0%}, flag rate {r['flag_rate']:.0%}, "
            f"rating {r['avg_rating']:.1f}  ->  {tag}"
        )
    return lines


# --------------------------------------------------------------------------- #
# Report rendering
# --------------------------------------------------------------------------- #
def render(report: HealthReport, table: pd.DataFrame) -> str:
    L = []
    L.append("=" * 68)
    L.append("SIGNALDESK -- WEEKLY HEALTH CHECK")
    L.append("=" * 68)
    L.append(
        f"Rows in export: {report.rows_in}   |   "
        f"Rows used after cleaning: {report.rows_used}"
    )
    L.append("")

    # 1. Data quality
    L.append("1) DATA QUALITY  (fix these at the source before trusting trends)")
    L.append("-" * 68)
    if not report.issues:
        L.append("  No issues found.")
    else:
        for i in report.issues:
            L.append(f"  [{i.kind}] {i.detail}")
    L.append("")

    # 2. Change events
    L.append("2) CHANGE EVENTS THIS WEEK")
    L.append("-" * 68)
    for e in report.events:
        L.append(f"  * {e}")
    L.append("")

    # 3. Workflow health
    L.append("3) WORKFLOW HEALTH  (rate-based, spike rows excluded)")
    L.append("-" * 68)
    show = table.copy()
    show["completion_rate"] = (show["completion_rate"] * 100).round(0).astype(int).astype(str) + "%"
    show["acceptance_rate"] = (show["acceptance_rate"] * 100).round(0).astype(int).astype(str) + "%"
    show["flag_rate"] = (show["flag_rate"] * 100).round(0).astype(int).astype(str) + "%"
    show["avg_rating"] = show["avg_rating"].round(1)
    show["avg_min_saved"] = show["avg_min_saved"].round(1)
    L.append(show.to_string())
    L.append("")

    # 4. Verdict
    L.append("4) READ  (what's working / what's suspicious)")
    L.append("-" * 68)
    L.extend(verdict_lines(table))
    L.append("")

    # 5. Trust + next steps
    L.append("5) TRUST & NEXT STEPS")
    L.append("-" * 68)
    L.append("  Trust LEAST: median_confidence -- it is model self-reported, not")
    L.append("    correctness. The demo-spike row had confidence 0.95 on junk data.")
    L.append("  Treat as directional: avg_minutes_saved (an estimate) and rating.")
    L.append("  Trust MOST: acceptance_rate and completion_rate on cleaned rows.")
    L.append("")
    L.append("  Investigate before rolling out wider:")
    L.append("   - The Aug-7 Support policy change: rating fell and flags spiked,")
    L.append("     but it's a partial day. Do NOT conclude yet -- collect 3-5 more")
    L.append("     days post-change, then re-run this check.")
    L.append("   - Fix the export at source: dedupe, standardize team casing, and")
    L.append("     stop writing 'n/a' into numeric columns.")
    L.append("   - Feedback clustering is low-volume: read outputs by hand, don't")
    L.append("     lean on the rates yet.")
    L.append("=" * 68)
    return "\n".join(L)


# --------------------------------------------------------------------------- #
def run(csv_path: str) -> tuple[str, HealthReport, pd.DataFrame]:
    df_raw = pd.read_csv(csv_path)
    report = HealthReport()
    df = clean(df_raw, report)
    report.events = detect_events(df)
    table = summarize(df, report)
    report.workflow_table = table
    return render(report, table), report, table


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="SignalDesk weekly health check")
    ap.add_argument(
        "csv", nargs="?",
        default="sample-data/product_usage_events.csv",
        help="Path to the weekly usage export CSV.",
    )
    ap.add_argument("--md", help="Optional path to also save the report as text/markdown.")
    args = ap.parse_args(argv)

    text, _report, _table = run(args.csv)
    print(text)
    if args.md:
        with open(args.md, "w") as fh:
            fh.write(text + "\n")
        print(f"\n[saved report to {args.md}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
